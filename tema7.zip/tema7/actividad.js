function scrollVertical() {
    window.scrollTo(0, 2000);
}

function scrollHorizontal() {
    window.scrollTo(2000, 0);
}